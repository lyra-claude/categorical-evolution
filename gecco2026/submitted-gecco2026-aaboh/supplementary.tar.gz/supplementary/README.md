# Supplementary Material: Composition Determines Diversity

## Contents

### `haskell-framework/`
The categorical evolution framework in Haskell. This is the source code for the
`categorical-evolution` library (https://github.com/lyra-claude/categorical-evolution).

Key modules:
- `haskell/src/Evolution/Category.hs` — Kleisli category and monad stack
- `haskell/src/Evolution/Operators.hs` — GA operators as Kleisli morphisms
- `haskell/src/Evolution/Pipeline.hs` — Pipeline composition (>>>:)
- `haskell/src/Evolution/Strategy.hs` — Strategy combinators (generational, hourglass, island, adaptive)
- `haskell/src/Evolution/Island.hs` — Island functor with migration topologies
- `haskell/src/Evolution/Landscape.hs` — Domain-specific fitness functions

Experiment scripts (Python, using the Haskell framework as backend):
- `haskell-framework/experiments/` — Six-domain topology sweep, fingerprint generation, statistical analysis

### `python-experiments/`
Python reimplementation of the strategy fingerprint experiments (Figure 2 in the paper).
- `strategy_fingerprints.py` — Runs flat/hourglass/island/adaptive strategies on maze, graph coloring, and knapsack domains with population 60, 50 generations, 10 seeds.

## Reproducing Results

### Topology ordering (Figure 1)
```bash
cd haskell-framework/experiments
python3 multi_domain_analysis.py  # requires experiment CSVs from the Haskell runs
```

### Strategy fingerprints (Figure 2)
```bash
cd python-experiments
python3 strategy_fingerprints.py
```

## Data Availability
Raw experimental data (CSV files, 30 seeds per condition) is available at:
https://github.com/lyra-claude/categorical-evolution/tree/main/experiments
